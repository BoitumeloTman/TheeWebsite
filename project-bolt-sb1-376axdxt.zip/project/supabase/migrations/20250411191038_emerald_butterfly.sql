/*
  # Initial Schema Setup

  1. New Tables
    - `profiles`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references auth.users)
      - `type` (text, either 'influencer' or 'brand')
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

    - `brands`
      - `id` (uuid, primary key)
      - `profile_id` (uuid, references profiles)
      - `name` (text)
      - `logo_url` (text)
      - `contact_number` (text)
      - `commission_rate` (numeric)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

    - `influencers`
      - `id` (uuid, primary key)
      - `profile_id` (uuid, references profiles)
      - `instagram_handle` (text)
      - `facebook_handle` (text)
      - `followers_count` (integer)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Create profiles table
CREATE TABLE profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users NOT NULL,
  type text NOT NULL CHECK (type IN ('influencer', 'brand')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create brands table
CREATE TABLE brands (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id uuid REFERENCES profiles NOT NULL,
  name text NOT NULL,
  logo_url text,
  contact_number text,
  commission_rate numeric CHECK (commission_rate >= 0 AND commission_rate <= 100),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create influencers table
CREATE TABLE influencers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id uuid REFERENCES profiles NOT NULL,
  instagram_handle text,
  facebook_handle text,
  followers_count integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE brands ENABLE ROW LEVEL SECURITY;
ALTER TABLE influencers ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can read own profile"
  ON profiles
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update own profile"
  ON profiles
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Brands can read own data"
  ON brands
  FOR SELECT
  TO authenticated
  USING (
    profile_id IN (
      SELECT id FROM profiles
      WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "Brands can update own data"
  ON brands
  FOR UPDATE
  TO authenticated
  USING (
    profile_id IN (
      SELECT id FROM profiles
      WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "Influencers can read own data"
  ON influencers
  FOR SELECT
  TO authenticated
  USING (
    profile_id IN (
      SELECT id FROM profiles
      WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "Influencers can update own data"
  ON influencers
  FOR UPDATE
  TO authenticated
  USING (
    profile_id IN (
      SELECT id FROM profiles
      WHERE user_id = auth.uid()
    )
  );