export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string
          user_id: string
          type: 'influencer' | 'brand'
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          type: 'influencer' | 'brand'
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          type?: 'influencer' | 'brand'
          created_at?: string
          updated_at?: string
        }
      }
      brands: {
        Row: {
          id: string
          profile_id: string
          name: string
          logo_url: string | null
          contact_number: string | null
          commission_rate: number | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          profile_id: string
          name: string
          logo_url?: string | null
          contact_number?: string | null
          commission_rate?: number | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          profile_id?: string
          name?: string
          logo_url?: string | null
          contact_number?: string | null
          commission_rate?: number | null
          created_at?: string
          updated_at?: string
        }
      }
      influencers: {
        Row: {
          id: string
          profile_id: string
          instagram_handle: string | null
          facebook_handle: string | null
          followers_count: number
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          profile_id: string
          instagram_handle?: string | null
          facebook_handle?: string | null
          followers_count?: number
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          profile_id?: string
          instagram_handle?: string | null
          facebook_handle?: string | null
          followers_count?: number
          created_at?: string
          updated_at?: string
        }
      }
    }
  }
}