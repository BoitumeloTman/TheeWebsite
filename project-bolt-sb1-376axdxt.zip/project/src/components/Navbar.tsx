import React from 'react';
import { Link } from 'react-router-dom';
import { Star, LogOut } from 'lucide-react';
import { useAuthStore } from '../store/auth';

const Navbar = () => {
  const { user, signOut } = useAuthStore();

  return (
    <nav className="bg-white/10 backdrop-blur-md border-b border-white/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Link to="/" className="flex items-center space-x-2">
              <Star className="h-8 w-8 text-yellow-400" />
              <span className="text-2xl font-bold text-white">Creator Hub</span>
            </Link>
          </div>
          <div className="flex items-center space-x-4">
            {user ? (
              <button
                onClick={() => signOut()}
                className="bg-white/10 hover:bg-white/20 text-white px-4 py-2 rounded-lg transition flex items-center"
              >
                <LogOut className="h-5 w-5 mr-2" />
                Sign Out
              </button>
            ) : (
              <>
                <Link
                  to="/influencer/auth"
                  className="bg-white/10 hover:bg-white/20 text-white px-4 py-2 rounded-lg transition"
                >
                  Influencer Login
                </Link>
                <Link
                  to="/brand/auth"
                  className="bg-white text-blue-900 px-4 py-2 rounded-lg hover:bg-white/90 transition"
                >
                  Brand Login
                </Link>
              </>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;