import { create } from 'zustand';
import { supabase } from '../lib/supabase';
import type { User, Provider } from '@supabase/supabase-js';

interface AuthState {
  user: User | null;
  profile: any | null;
  loading: boolean;
  signUp: (email: string, password: string, type: 'influencer' | 'brand') => Promise<void>;
  signIn: (email: string, password: string) => Promise<void>;
  signInWithSocial: (provider: Provider, type: 'influencer' | 'brand') => Promise<void>;
  signOut: () => Promise<void>;
  loadUser: () => Promise<void>;
}

export const useAuthStore = create<AuthState>((set) => ({
  user: null,
  profile: null,
  loading: true,
  signUp: async (email: string, password: string, type: 'influencer' | 'brand') => {
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
    });

    if (error) throw error;

    if (data.user) {
      // Create profile
      const { error: profileError } = await supabase
        .from('profiles')
        .insert([
          {
            user_id: data.user.id,
            type,
          },
        ]);

      if (profileError) throw profileError;
    }
  },
  signIn: async (email: string, password: string) => {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (error) throw error;

    if (data.user) {
      const { data: profile } = await supabase
        .from('profiles')
        .select('*')
        .eq('user_id', data.user.id)
        .single();

      set({ user: data.user, profile });
    }
  },
  signInWithSocial: async (provider: Provider, type: 'influencer' | 'brand') => {
    const { data, error } = await supabase.auth.signInWithOAuth({
      provider,
      options: {
        redirectTo: `${window.location.origin}/auth/callback`,
        queryParams: {
          user_type: type,
        },
      },
    });

    if (error) throw error;

    // Profile will be created in the callback handler
    return data;
  },
  signOut: async () => {
    const { error } = await supabase.auth.signOut();
    if (error) throw error;
    set({ user: null, profile: null });
  },
  loadUser: async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (user) {
        const { data: profile } = await supabase
          .from('profiles')
          .select('*')
          .eq('user_id', user.id)
          .single();

        set({ user, profile });
      }
    } catch (error) {
      console.error('Error loading user:', error);
    } finally {
      set({ loading: false });
    }
  },
}));