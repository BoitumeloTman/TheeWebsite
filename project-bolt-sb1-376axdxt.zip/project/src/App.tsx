import React, { useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import InfluencerAuth from './pages/InfluencerAuth';
import BrandAuth from './pages/BrandAuth';
import BrandDashboard from './pages/BrandDashboard';
import InfluencerDashboard from './pages/InfluencerDashboard';
import AuthCallback from './pages/AuthCallback';
import { useAuthStore } from './store/auth';

function App() {
  const { loadUser, user, profile, loading } = useAuthStore();

  useEffect(() => {
    loadUser();
  }, [loadUser]);

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-900 to-indigo-900 flex items-center justify-center">
        <div className="text-white text-xl">Loading...</div>
      </div>
    );
  }

  return (
    <BrowserRouter>
      <div className="min-h-screen bg-gradient-to-br from-blue-900 to-indigo-900">
        <Navbar />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/auth/callback" element={<AuthCallback />} />
          <Route
            path="/influencer/auth"
            element={
              user ? (
                <Navigate to="/influencer/dashboard" />
              ) : (
                <InfluencerAuth />
              )
            }
          />
          <Route
            path="/brand/auth"
            element={
              user ? (
                <Navigate to="/brand/dashboard" />
              ) : (
                <BrandAuth />
              )
            }
          />
          <Route
            path="/brand/dashboard"
            element={
              user && profile?.type === 'brand' ? (
                <BrandDashboard />
              ) : (
                <Navigate to="/brand/auth" />
              )
            }
          />
          <Route
            path="/influencer/dashboard"
            element={
              user && profile?.type === 'influencer' ? (
                <InfluencerDashboard />
              ) : (
                <Navigate to="/influencer/auth" />
              )
            }
          />
        </Routes>
      </div>
    </BrowserRouter>
  );
}

export default App;