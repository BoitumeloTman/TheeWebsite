import React from 'react';
import { DollarSign, Share2, ShoppingBag } from 'lucide-react';

const InfluencerDashboard = () => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-3xl font-bold text-white">Creator Dashboard</h1>
        <div className="flex items-center space-x-2">
          <img
            src="https://images.unsplash.com/photo-1494790108377-be9c29b29330"
            alt="Profile"
            className="w-10 h-10 rounded-full"
          />
          <div>
            <p className="text-white font-medium">Sarah Johnson</p>
            <p className="text-white/60 text-sm">1.2M Followers</p>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white/10 backdrop-blur-md rounded-xl p-6">
          <div className="flex items-center">
            <DollarSign className="h-8 w-8 text-green-400" />
            <div className="ml-4">
              <p className="text-sm text-white/60">Total Earnings</p>
              <p className="text-2xl font-bold text-white">$8,450</p>
            </div>
          </div>
        </div>
        <div className="bg-white/10 backdrop-blur-md rounded-xl p-6">
          <div className="flex items-center">
            <Share2 className="h-8 w-8 text-blue-400" />
            <div className="ml-4">
              <p className="text-sm text-white/60">Active Partnerships</p>
              <p className="text-2xl font-bold text-white">12</p>
            </div>
          </div>
        </div>
        <div className="bg-white/10 backdrop-blur-md rounded-xl p-6">
          <div className="flex items-center">
            <ShoppingBag className="h-8 w-8 text-purple-400" />
            <div className="ml-4">
              <p className="text-sm text-white/60">Total Sales</p>
              <p className="text-2xl font-bold text-white">324</p>
            </div>
          </div>
        </div>
      </div>

      {/* Active Partnerships */}
      <div className="bg-white/10 backdrop-blur-md rounded-xl p-6 mb-8">
        <h2 className="text-xl font-semibold text-white mb-4">Active Partnerships</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3].map((brand) => (
            <div key={brand} className="bg-white/5 rounded-lg p-4">
              <img
                src={`https://via.placeholder.com/150?text=Brand${brand}`}
                alt={`Brand ${brand}`}
                className="w-16 h-16 rounded-lg mb-4"
              />
              <h3 className="text-lg font-medium text-white mb-2">Brand Name</h3>
              <p className="text-white/60 mb-2">Commission: 12%</p>
              <p className="text-white/60">Sales: 45</p>
            </div>
          ))}
        </div>
      </div>

      {/* Performance Analytics */}
      <div className="bg-white/10 backdrop-blur-md rounded-xl p-6">
        <h2 className="text-xl font-semibold text-white mb-4">Performance Analytics</h2>
        <div className="h-64 bg-white/5 rounded-lg flex items-center justify-center">
          <p className="text-white/60">Analytics Chart Placeholder</p>
        </div>
      </div>
    </div>
  );
};

export default InfluencerDashboard;