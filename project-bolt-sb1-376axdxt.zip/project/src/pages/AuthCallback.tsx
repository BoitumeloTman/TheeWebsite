import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';

const AuthCallback = () => {
  const navigate = useNavigate();

  useEffect(() => {
    const handleCallback = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (user) {
        // Get the user type from the URL parameters
        const params = new URLSearchParams(window.location.search);
        const userType = params.get('user_type');

        if (!userType) {
          navigate('/');
          return;
        }

        // Create profile if it doesn't exist
        const { data: existingProfile } = await supabase
          .from('profiles')
          .select('id')
          .eq('user_id', user.id)
          .single();

        if (!existingProfile) {
          const { data: profile } = await supabase
            .from('profiles')
            .insert([
              {
                user_id: user.id,
                type: userType,
              },
            ])
            .select()
            .single();

          if (profile && userType === 'influencer') {
            await supabase.from('influencers').insert([
              {
                profile_id: profile.id,
                followers_count: 0,
              },
            ]);
          }
        }

        // Redirect based on user type
        navigate(userType === 'influencer' ? '/influencer/dashboard' : '/brand/dashboard');
      } else {
        navigate('/');
      }
    };

    handleCallback();
  }, [navigate]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 to-indigo-900 flex items-center justify-center">
      <div className="text-white text-xl">Completing login...</div>
    </div>
  );
};

export default AuthCallback;