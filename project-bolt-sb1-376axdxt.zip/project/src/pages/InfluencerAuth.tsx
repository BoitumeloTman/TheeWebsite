import React, { useState } from 'react';
import { Instagram, Facebook } from 'lucide-react';
import { useAuthStore } from '../store/auth';
import { supabase } from '../lib/supabase';
import type { Provider } from '@supabase/supabase-js';

const InfluencerAuth = () => {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const { signIn, signUp, signInWithSocial } = useAuthStore();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      if (isLogin) {
        await signIn(email, password);
      } else {
        await signUp(email, password, 'influencer');
        
        // Create influencer profile
        const { data: { user } } = await supabase.auth.getUser();
        if (user) {
          const { data: profile } = await supabase
            .from('profiles')
            .select('id')
            .eq('user_id', user.id)
            .single();

          if (profile) {
            await supabase.from('influencers').insert([
              {
                profile_id: profile.id,
                followers_count: 0,
              },
            ]);
          }
        }
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    } finally {
      setLoading(false);
    }
  };

  const handleSocialLogin = async (provider: Provider) => {
    try {
      setError(null);
      setLoading(true);
      await signInWithSocial(provider, 'influencer');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
      setLoading(false);
    }
  };

  return (
    <div className="max-w-md mx-auto mt-20 p-6 bg-white/10 backdrop-blur-md rounded-xl">
      <h2 className="text-3xl font-bold text-white mb-6 text-center">
        {isLogin ? 'Creator Login' : 'Creator Registration'}
      </h2>

      {error && (
        <div className="bg-red-500/10 border border-red-500/20 text-red-400 p-3 rounded-lg mb-4">
          {error}
        </div>
      )}

      <div className="space-y-4">
        <button 
          onClick={() => handleSocialLogin('instagram')}
          disabled={loading}
          className="w-full bg-[#E1306C] text-white py-3 px-4 rounded-lg flex items-center justify-center hover:bg-opacity-90 transition disabled:opacity-50"
        >
          <Instagram className="h-5 w-5 mr-2" />
          Continue with Instagram
        </button>

        <button
          onClick={() => handleSocialLogin('facebook')}
          disabled={loading}
          className="w-full bg-[#1877F2] text-white py-3 px-4 rounded-lg flex items-center justify-center hover:bg-opacity-90 transition disabled:opacity-50"
        >
          <Facebook className="h-5 w-5 mr-2" />
          Continue with Facebook
        </button>

        <div className="relative">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-white/20"></div>
          </div>
          <div className="relative flex justify-center text-sm">
            <span className="px-2 bg-blue-900 text-white/60">Or</span>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <input
              type="email"
              placeholder="Email address"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-white/60 focus:outline-none focus:ring-2 focus:ring-white/40"
            />
          </div>
          <div>
            <input
              type="password"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-white/60 focus:outline-none focus:ring-2 focus:ring-white/40"
            />
          </div>
          <button
            type="submit"
            disabled={loading}
            className="w-full bg-white text-blue-900 py-3 px-4 rounded-lg font-semibold hover:bg-white/90 transition disabled:opacity-50"
          >
            {loading ? 'Please wait...' : isLogin ? 'Sign In' : 'Create Account'}
          </button>
        </form>

        <p className="text-center text-white/60">
          {isLogin ? "Don't have an account? " : "Already have an account? "}
          <button
            onClick={() => setIsLogin(!isLogin)}
            className="text-white hover:underline"
          >
            {isLogin ? 'Sign up' : 'Sign in'}
          </button>
        </p>
      </div>
    </div>
  );
};

export default InfluencerAuth;