import React from 'react';
import { ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

const Home = () => {
  const featuredInfluencers = [
    {
      id: 1,
      name: "Sarah Johnson",
      image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330",
      followers: "1.2M",
      category: "Lifestyle"
    },
    {
      id: 2,
      name: "Mike Chen",
      image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e",
      followers: "850K",
      category: "Tech"
    },
    {
      id: 3,
      name: "Emma Davis",
      image: "https://images.unsplash.com/photo-1534528741775-53994a69daeb",
      followers: "2.1M",
      category: "Fashion"
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      {/* Hero Section */}
      <div className="relative mb-20">
        <video
          autoPlay
          muted
          loop
          className="absolute inset-0 w-full h-full object-cover rounded-2xl opacity-50"
          style={{ height: '600px' }}
        >
          <source
            src="https://cdn.coverr.co/videos/coverr-content-creator-working-on-laptop-2633/1080p.mp4"
            type="video/mp4"
          />
        </video>
        <div className="relative z-10 py-32 text-center">
          <h1 className="text-5xl font-bold mb-6 text-white">
            Connect with Top Brands & Creators
          </h1>
          <p className="text-xl text-white/90 mb-8 max-w-2xl mx-auto">
            Join our marketplace where influential creators meet innovative brands.
            Build partnerships that drive growth and create authentic connections.
          </p>
          <div className="flex justify-center space-x-4">
            <Link
              to="/influencer/auth"
              className="bg-white text-blue-900 px-8 py-3 rounded-lg font-semibold hover:bg-white/90 transition flex items-center"
            >
              Join as Creator <ArrowRight className="ml-2 h-5 w-5" />
            </Link>
            <Link
              to="/brand/auth"
              className="bg-blue-700 text-white px-8 py-3 rounded-lg font-semibold hover:bg-blue-600 transition flex items-center"
            >
              Register Brand <ArrowRight className="ml-2 h-5 w-5" />
            </Link>
          </div>
        </div>
      </div>

      {/* Featured Influencers */}
      <section className="mb-20">
        <h2 className="text-3xl font-bold text-white mb-8">Featured Creators</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {featuredInfluencers.map((influencer) => (
            <div
              key={influencer.id}
              className="bg-white/10 backdrop-blur-md rounded-xl p-6 transform hover:scale-105 transition"
            >
              <img
                src={influencer.image}
                alt={influencer.name}
                className="w-full h-64 object-cover rounded-lg mb-4"
              />
              <h3 className="text-xl font-semibold text-white mb-2">{influencer.name}</h3>
              <p className="text-white/80">{influencer.category}</p>
              <p className="text-white/80">{influencer.followers} followers</p>
            </div>
          ))}
        </div>
      </section>

      {/* Statistics */}
      <section className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-20">
        <div className="bg-white/10 backdrop-blur-md rounded-xl p-8 text-center">
          <h3 className="text-4xl font-bold text-white mb-2">1000+</h3>
          <p className="text-white/80">Active Creators</p>
        </div>
        <div className="bg-white/10 backdrop-blur-md rounded-xl p-8 text-center">
          <h3 className="text-4xl font-bold text-white mb-2">500+</h3>
          <p className="text-white/80">Partner Brands</p>
        </div>
        <div className="bg-white/10 backdrop-blur-md rounded-xl p-8 text-center">
          <h3 className="text-4xl font-bold text-white mb-2">$2M+</h3>
          <p className="text-white/80">Creator Earnings</p>
        </div>
      </section>
    </div>
  );
};

export default Home;