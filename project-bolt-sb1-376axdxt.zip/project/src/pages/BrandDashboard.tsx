import React from 'react';
import { Users, DollarSign, BarChart } from 'lucide-react';

const BrandDashboard = () => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <h1 className="text-3xl font-bold text-white mb-8">Brand Dashboard</h1>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white/10 backdrop-blur-md rounded-xl p-6">
          <div className="flex items-center">
            <Users className="h-8 w-8 text-blue-400" />
            <div className="ml-4">
              <p className="text-sm text-white/60">Active Influencers</p>
              <p className="text-2xl font-bold text-white">245</p>
            </div>
          </div>
        </div>
        <div className="bg-white/10 backdrop-blur-md rounded-xl p-6">
          <div className="flex items-center">
            <DollarSign className="h-8 w-8 text-green-400" />
            <div className="ml-4">
              <p className="text-sm text-white/60">Total Sales</p>
              <p className="text-2xl font-bold text-white">$12,450</p>
            </div>
          </div>
        </div>
        <div className="bg-white/10 backdrop-blur-md rounded-xl p-6">
          <div className="flex items-center">
            <BarChart className="h-8 w-8 text-purple-400" />
            <div className="ml-4">
              <p className="text-sm text-white/60">Conversion Rate</p>
              <p className="text-2xl font-bold text-white">3.2%</p>
            </div>
          </div>
        </div>
      </div>

      {/* Brand Profile */}
      <div className="bg-white/10 backdrop-blur-md rounded-xl p-6 mb-8">
        <h2 className="text-xl font-semibold text-white mb-4">Brand Profile</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <img
              src="https://via.placeholder.com/150"
              alt="Brand Logo"
              className="w-32 h-32 rounded-lg mb-4"
            />
            <h3 className="text-lg font-medium text-white">FitPro Gear</h3>
            <p className="text-white/60">Premium Fitness Equipment</p>
          </div>
          <div>
            <p className="text-white/80 mb-2">
              <span className="font-medium">Commission Rate:</span> 12%
            </p>
            <p className="text-white/80 mb-2">
              <span className="font-medium">Contact:</span> contact@fitprogear.com
            </p>
            <p className="text-white/80">
              <span className="font-medium">Phone:</span> +1 (555) 123-4567
            </p>
          </div>
        </div>
      </div>

      {/* Active Campaigns */}
      <div className="bg-white/10 backdrop-blur-md rounded-xl p-6">
        <h2 className="text-xl font-semibold text-white mb-4">Active Campaigns</h2>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="text-white/60 text-left">
                <th className="pb-4">Campaign</th>
                <th className="pb-4">Influencers</th>
                <th className="pb-4">Sales</th>
                <th className="pb-4">Status</th>
              </tr>
            </thead>
            <tbody className="text-white">
              <tr className="border-t border-white/10">
                <td className="py-4">Summer Collection</td>
                <td>12</td>
                <td>$3,450</td>
                <td>
                  <span className="bg-green-500/20 text-green-400 px-2 py-1 rounded-full text-sm">
                    Active
                  </span>
                </td>
              </tr>
              <tr className="border-t border-white/10">
                <td className="py-4">Holiday Special</td>
                <td>8</td>
                <td>$2,180</td>
                <td>
                  <span className="bg-yellow-500/20 text-yellow-400 px-2 py-1 rounded-full text-sm">
                    Pending
                  </span>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default BrandDashboard;